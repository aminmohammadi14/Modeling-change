# =============================================================================
#  REVCS33.jl  --  Multiperiod REVCS planning, 33P-12U system (HiGHS default, SCIP optional)
#  Reference: Xiong, Shahidehpour, Shi, Luo, Guo, IEEE TTE 11(1), 2025,
#             DOI 10.1109/TTE.2024.3446461   (+ the paper's data appendix)
#
#  What this file contains
#    1. Data of the 33P-12U system (PDN 33 bus/37 lines, UTN 12 nodes/20 roads)
#    2. add_stage!  : one planning period, Eq. 2-44 (+ scenario values, Eq. 45-53)
#    3. build_stage : stage MILP with binarised state (SDDiP-style, Sec. III-A)
#    4. Cuts        : strengthened-Benders + Lagrangian (Eq. 60) + integer-optimality
#    5. rddp        : forward/backward cuts; UB = evaluated finite-tree policy
#    6. ccg_exact   : nested C&CG with lower and upper bounds on the same finite tree
#    7. evaluate_policy : full policy tree with cost breakdown (CSV)
#
#  HONEST SCOPE (read before trusting numbers)
#    * The worst case over Phi_t is taken over a finite, structured scenario set
#      (growth values crossed with correlated hourly patterns).
#      Bounds are therefore bounds for THAT finite set.
#    * Several modelling choices are NOT fixed by the paper; they are listed in
#      ASSUMPTIONS below and exposed as Cfg options.
#    * The paper's upper bound (approximate convex hull, Eq. 61) is replaced by the
#      exact value of the current policy on the tree: always a valid upper bound.
# =============================================================================
module REVCS33

using JuMP, HiGHS, Printf, LinearAlgebra
const MOI = JuMP.MOI

include(joinpath(@__DIR__, "data33.jl"))   # OD_FLOW, WT_PU, PV_PU, LOAD_KW (24x*)

export Cfg, build_inst, rddp, evaluate_policy, ccg_exact, initial_state, solve_stage, scen_nominal, scen_set,
       encode, report_state

# ----------------------------------------------------------------------------
# Input conventions and diagnostic assumptions
# Table II implies the growth multipliers in GROWTH. Fig. 9(c,d) has
# different stage-3 forecast labels. The audit reports both.
# The actual path list, voltage convention, reactive demand, BESS boundary,
# discount rate, charging energy and RDDP capacity grid are unpublished.
# The defaults below are assumptions for diagnostic runs.
# Eq. (33) and (20) can use their printed capacities or the full current
# capacity. Fig. 8 motivates the latter for the construction period.
# Appendix Tables 9 and 10 give the BESS ramp and nominal voltage.
# Scenario patterns define a restricted tree. Table II is used for validation,
# never entered as a dispatch, investment, cost, or convergence target.
Base.@kwdef mutable struct Cfg
    T::Int = 3
    days::Vector{Int} = [1]                  # typical days used (1..4)
    hours::Vector{Int} = [3, 9, 14, 19]      # hours of day used (1..24)
    step::Float64 = 20.0                     # binarisation step [kW]
    sigma::Float64 = 0.05
    gamma::Float64 = 0.24                    # gamma1*gamma2 (Table 10)
    dp::Float64 = 1.0                        # kWh per charging vehicle (Eq.32)
    amp::Float64 = 1.0
    cap_mode::Symbol = :current
    K::Int = 27     # inferred from Table I; memberships are unpublished
    compact_traffic::Bool = false
    load_tanphi::Float64 = 0.30
    vbase_kV::Float64 = 12.66
    corner_only::Bool = true                 # Phi_t growth: corners only (true) or {lo,fc,hi}
    patterns::Vector{Symbol} = [:fc, :lo, :hi, :adv]
    time_limit::Float64 = 120.0
    mip_gap::Float64 = 1e-4
    threads::Int = 8
    lag_iters::Int = 3
    refine_rounds::Int = 20                  # inner cut rounds at stage T-1 nodes (0 = plain RDDP)
    refine_tol::Float64 = 1e-4
    solver::Symbol = :highs                  # :highs (default) or :scip (if SCIP.jl is installed)
    verbose::Bool = false
    verbose_cuts::Bool = false
end

# ----------------------------------------------------------------------------
# Instance
# ----------------------------------------------------------------------------
const ROAD_NODES = [(1,3),(1,2),(2,6),(1,4),(2,5),(3,4),(4,5),(5,6),(3,7),(4,8),
                    (5,9),(6,10),(7,8),(8,9),(9,10),(7,11),(8,11),(9,12),(10,12),(11,12)]
const ROAD_CAP = [3528.0,3920.0,3332.0,1920.8,1548.4,1666.0,2646.0,1607.2,3724.0,2744.0,
                  2704.8,3920.0,1744.4,2587.2,1792.0,3430.0,1912.4,1758.4,3567.2,3920.0]
const ROAD_H0  = [6.0,10.0,6.5,5.0,5.5,6.0,12.0,6.5,10.2,11.5,12.5,10.5,5.8,11.0,5.9,6.3,5.7,5.8,6.1,9.8]
const ROAD_BUS = [3,4,5,29,7,14,18,10,19,12,13,8,15,16,17,33,32,23,21,26]   # road a <-> bus
const EXISTING = [2,3,10,14,16]
const OD_PAIRS = [(1,6),(1,10),(1,12),(3,6),(3,12),(3,11),(4,9),(4,10),(4,12)]  # columns of OD_FLOW
# PDN lines: from, to, r, x, Pcap
const LINES = [
 (1,2,0.0922,0.0470,3047.13),(2,3,0.4930,0.2511,2549.40),(3,4,0.3660,0.1864,2164.76),
 (4,5,0.3811,0.1941,2668.01),(5,6,0.8190,0.7070,2457.81),(6,7,0.1872,0.6188,2300.48),
 (7,8,0.7114,0.2351,2048.59),(8,9,1.0300,0.7400,2966.33),(9,10,1.0440,0.7400,2688.23),
 (10,11,0.1966,0.0650,2851.36),(11,12,0.3744,0.1238,2355.47),(12,13,1.4680,1.1550,2705.91),
 (13,14,0.5416,0.7129,2541.76),(14,15,0.5910,0.5260,2520.55),(15,16,0.7463,0.5450,2286.02),
 (16,17,1.2890,1.7210,2613.39),(17,18,0.7320,0.5740,2402.82),(2,19,0.1640,0.1565,2596.22),
 (19,20,1.5042,1.3554,2438.83),(20,21,0.4095,0.4784,2673.81),(21,22,0.7089,0.9373,2590.52),
 (3,23,0.4512,0.3083,2336.64),(23,24,0.8980,0.7091,2808.84),(24,25,0.8960,0.7011,2707.61),
 (6,26,0.2030,0.1034,2543.83),(26,27,0.2842,0.1447,2296.86),(27,28,1.0590,0.9337,2302.25),
 (28,29,0.8042,0.7006,2497.54),(29,30,0.5075,0.2585,2507.18),(30,31,0.9744,0.9630,2243.74),
 (31,32,0.3105,0.3619,2413.65),(32,33,0.3410,0.5302,2596.15),
 (21,8,2.0,2.0,2379.71),(9,15,2.0,2.0,2427.50),(12,22,2.0,2.0,2767.34),
 (18,33,0.5,0.5,2756.41),(25,29,0.5,0.5,2776.44)]
# DREs: (bus, capacity kW, kind)   WT then PV
const DRES = [(4,263.5,:wt),(13,395.0,:wt),(22,395.0,:wt),(27,197.5,:wt),(31,461.0,:wt),
              (7,253.0,:pv),(11,184.0,:pv),(17,276.5,:pv),(19,138.0,:pv),(25,322.5,:pv)]
# Table 7/9/10 and Sec. IV costs
const C0 = (c=200.0, e=40.0, v=60.0)         # basic capacities of a (new/existing) REVCS
const EBAR = (c=200.0, e=40.0, v=60.0)       # per-period expansion limits
const COST = (rvc=110_000.0, man=20_000.0, fc=200.0, es=600.0, pv=1000.0,
              curt=2.0, unb=10.0, su=0.3, fr=0.012, ja=0.04)
const PBU = 4800.0; const SW = 468.0; const TANG = 0.20
const VMIN = 0.93; const VMAX = 1.05; const VNOM = 1.03
const BESS_P = 20.0; const ETA_C = 0.95; const ETA_D = 0.90
const GROWTH = Dict(  # (lo, fc, hi)
  :td  => Dict(1=>(1.0,1.0,1.0), 2=>(1.3,1.4,1.5), 3=>(1.8,1.9,2.0)),
  :dre => Dict(1=>(1.0,1.0,1.0), 2=>(1.3,1.4,1.5), 3=>(1.7,1.85,2.0)))
const WT_RNG = (0.75, 1.0, 1.25); const PV_RNG = (0.9, 1.0, 1.1)

function k_shortest_paths(s, t, K)
    adj = Dict{Int,Vector{Tuple{Int,Int}}}()
    for (r,(a,b)) in enumerate(ROAD_NODES)
        push!(get!(adj,a,Tuple{Int,Int}[]), (b,r)); push!(get!(adj,b,Tuple{Int,Int}[]), (a,r))
    end
    out = Vector{Vector{Int}}()
    function dfs(n, vis, rs)
        if n == t; push!(out, copy(rs)); return; end
        for (m,r) in adj[n]
            m in vis && continue
            push!(vis,m); push!(rs,r); dfs(m,vis,rs); pop!(rs); delete!(vis,m)
        end
    end
    dfs(s, Set([s]), Int[])
    sort!(out, by = p -> (sum(round(Int, 10 * ROAD_H0[r]) for r in p), length(p), p))
    return out[1:min(K, length(out))]
end

function build_inst(cfg::Cfg)
    1 <= cfg.T <= 3 || throw(ArgumentError("33P-12U defines one to three periods"))
    cfg.cap_mode in (:current, :printed) || throw(ArgumentError("unknown capacity convention"))
    cfg.step > 0 && isfinite(cfg.step) || throw(ArgumentError("capacity step must be finite and positive"))
    all(x -> isapprox(x / cfg.step, round(x / cfg.step); atol=1e-8, rtol=0), values(C0)) ||
        throw(ArgumentError("capacity step must represent all base capacities"))
    !isempty(cfg.days) && all(in(1:4), cfg.days) && allunique(cfg.days) ||
        throw(ArgumentError("days must be unique and within 1:4"))
    !isempty(cfg.hours) && all(in(1:24), cfg.hours) && issorted(cfg.hours) && allunique(cfg.hours) ||
        throw(ArgumentError("hours must be unique, increasing and within 1:24"))
    cfg.K > 0 || throw(ArgumentError("path count must be positive"))
    !isempty(cfg.patterns) && all(in((:fc, :lo, :hi, :adv)), cfg.patterns) && allunique(cfg.patterns) ||
        throw(ArgumentError("invalid scenario patterns"))
    tois = [(d,h) for d in cfg.days for h in cfg.hours]
    groups = [findall(x -> x[1]==d, tois) for d in cfg.days]
    paths = Vector{Vector{Int}}(); pod = Int[]
    for (o,(s,t)) in enumerate(OD_PAIRS)
        for p in k_shortest_paths(s,t,cfg.K); push!(paths,p); push!(pod,o); end
    end
    A = length(ROAD_NODES)
    thr = [findall(p -> a in p, paths) for a in 1:A]                 # paths through road a
    podl = [findall(==(o), pod) for o in 1:length(OD_PAIRS)]
    Cmax = (c = C0.c + cfg.T*EBAR.c, e = C0.e + cfg.T*EBAR.e, v = C0.v + cfg.T*EBAR.v)
    nb = (ceil(Int, log2(Cmax.c/cfg.step + 1)), ceil(Int, log2(Cmax.e/cfg.step + 1)),
          ceil(Int, log2(Cmax.v/cfg.step + 1)))
    bpa = 1 + sum(nb)
    nbus = 33
    lin  = [findall(l -> LINES[l][2]==i, eachindex(LINES)) for i in 1:nbus]
    lout = [findall(l -> LINES[l][1]==i, eachindex(LINES)) for i in 1:nbus]
    dre_at = [[g for g in eachindex(DRES) if DRES[g][1] == i] for i in 1:nbus]
    sta_at = [[a for a in 1:A if ROAD_BUS[a] == i] for i in 1:nbus]
    return (cfg=cfg, tois=tois, groups=groups, A=A, paths=paths, pod=pod, thr=thr, podl=podl,
            nb=nb, bpa=bpa, nbit=A*bpa, nbus=nbus, lin=lin, lout=lout, Cmax=Cmax,
            dre_at=dre_at, sta_at=sta_at, traffic_cache=Dict{Tuple{Int,Float64},NamedTuple}())
end

# ----------------------------------------------------------------------------
# State handling (binarised: z, Cc, Ce, Cv)   x = (z, Cc, Ce, Cv)
# ----------------------------------------------------------------------------
initial_state(I) = (z = [a in EXISTING ? 1.0 : 0.0 for a in 1:I.A],
                    Cc = [a in EXISTING ? C0.c : 0.0 for a in 1:I.A],
                    Ce = [a in EXISTING ? C0.e : 0.0 for a in 1:I.A],
                    Cv = [a in EXISTING ? C0.v : 0.0 for a in 1:I.A])

function unpack(I, b)
    nbc, nbe, nbv = I.nb; st = I.cfg.step
    off(a) = (a-1)*I.bpa
    z  = [b[off(a)+1] for a in 1:I.A]
    Cc = [st*sum(2.0^(k-1)*b[off(a)+1+k] for k in 1:nbc) for a in 1:I.A]
    Ce = [st*sum(2.0^(k-1)*b[off(a)+1+nbc+k] for k in 1:nbe) for a in 1:I.A]
    Cv = [st*sum(2.0^(k-1)*b[off(a)+1+nbc+nbe+k] for k in 1:nbv) for a in 1:I.A]
    return (z=z, Cc=Cc, Ce=Ce, Cv=Cv)
end

function encode(I, x)
    nbc, nbe, nbv = I.nb; st = I.cfg.step
    b = zeros(I.nbit)
    function put!(base, n, val)
        q = round(Int, val/st); abs(q*st - val) < 1e-6 || error("capacity $val not a multiple of step")
        0 <= q < 2^n || error("capacity overflow")
        for k in 1:n; b[base+k] = (q >> (k-1)) & 1; end
    end
    for a in 1:I.A
        o = (a-1)*I.bpa
        b[o+1] = round(x.z[a])
        put!(o+1, nbc, x.Cc[a]); put!(o+1+nbc, nbe, x.Ce[a]); put!(o+1+nbc+nbe, nbv, x.Cv[a])
    end
    return b
end

# ----------------------------------------------------------------------------
# Scenarios (one realisation of xi_t)
# ----------------------------------------------------------------------------
struct Scen
    name::String
    td::Float64
    dre::Float64
    xi::Matrix{Float64}      # G x n  multiplier on DRE p.u. output (Eq.50-51)
    zeta::Matrix{Float64}    # A x n  multiplier on onsite PV p.u. output
end

function scen_pattern(I, t, td, dre, pat::Symbol, name)
    n = length(I.tois); G = length(DRES)
    xi = ones(G, n); ze = ones(I.A, n)
    t == 1 && return Scen(name, td, dre, xi, ze)           # stage 1 deterministic (xi_1 = forecast)
    loads = [LOAD_KW[h, d] for (d,h) in I.tois]; med = sort(loads)[cld(n,2)]
    for j in 1:n, g in 1:G
        wt = DRES[g][3] == :wt
        lo = wt ? WT_RNG[1] : PV_RNG[1]; hi = wt ? WT_RNG[3] : PV_RNG[3]
        v = pat == :fc ? 1.0 : pat == :lo ? lo : pat == :hi ? hi :
            pat == :adv ? (loads[j] >= med ? lo : hi) : error("pattern")
        xi[g,j] = v
    end
    for j in 1:n
        v = pat == :fc ? 1.0 : pat == :lo ? PV_RNG[1] : pat == :hi ? PV_RNG[3] :
            (loads[j] >= med ? PV_RNG[1] : PV_RNG[3])
        ze[:,j] .= v
    end
    return Scen(name, td, dre, xi, ze)
end

scen_nominal(I, t) = scen_pattern(I, t, GROWTH[:td][t][2], GROWTH[:dre][t][2], :fc, "nominal")

function scen_set(I, t)
    t == 1 && return [scen_nominal(I, 1)]
    out = Scen[]
    idx = I.cfg.corner_only ? (1,3) : (1,2,3)
    for i in idx, j in idx, p in I.cfg.patterns
        push!(out, scen_pattern(I, t, GROWTH[:td][t][i], GROWTH[:dre][t][j], p,
                                "td$(i)_dre$(j)_$(p)"))
    end
    return out
end

# ----------------------------------------------------------------------------
# Cuts / hull
# ----------------------------------------------------------------------------
struct Cut; alpha::Float64; pi::Vector{Float64}; end

# ----------------------------------------------------------------------------
# Solver factory (solver-agnostic MOI attributes; HiGHS is the default)
# ----------------------------------------------------------------------------
const SOLVERS = Dict{Symbol,Any}(:highs => HiGHS.Optimizer)
register_solver!(name::Symbol, opt) = (SOLVERS[name] = opt)

function new_model(cfg)
    haskey(SOLVERS, cfg.solver) || error("solver $(cfg.solver) not registered (register_solver!)")
    m = Model(SOLVERS[cfg.solver])
    cfg.verbose || set_silent(m)
    set_time_limit_sec(m, cfg.time_limit)
    set_attribute(m, MOI.RelativeGapTolerance(), cfg.mip_gap)
    try set_attribute(m, MOI.NumberOfThreads(), cfg.threads) catch end
    return m
end

# Eqs. (6)–(17) are the primal and dual of minimum free-flow travel time.
# Route capacities are shared by both traffic classes. The aggregate demand
# LP has exactly the same value: every aggregate solution can be split by γ.
# Among its optimal duals, minimize the congestion-price term in Eq. (5).
# Strong duality then holds for every optimal primal, so non-tight routes
# under that dual can be removed before building the coupled problem.
function traffic_equilibrium(I, h, multiplier)
    return get!(I.traffic_cache, (h, multiplier)) do
        m = new_model(I.cfg)
        demand = multiplier .* OD_FLOW[h, :]
        A = I.A
        P = length(I.paths)
        O = length(I.podl)
        time = [sum(ROAD_H0[I.paths[p]]) for p in 1:P]
        @variable(m, flow[1:P] >= 0)
        @constraint(m, [o=1:O], sum(flow[p] for p in I.podl[o]) == demand[o])
        @constraint(m, [a=1:A], sum(flow[p] for p in I.thr[a]; init=0.0) <= ROAD_CAP[a])
        @objective(m, Min, dot(time, flow))
        optimize!(m)
        termination_status(m) == MOI.OPTIMAL || error("Traffic equilibrium hour $h: $(termination_status(m))")
        free = objective_value(m)

        dual = new_model(I.cfg)
        @variable(dual, λ[1:A] >= 0)
        @variable(dual, ϕ[1:O])
        @constraint(dual, [p=1:P], ϕ[I.pod[p]] <= time[p] + sum(λ[a] for a in I.paths[p]))
        @constraint(dual, dot(demand, ϕ) - dot(ROAD_CAP, λ) == free)
        @objective(dual, Min, dot(ROAD_CAP, λ))
        optimize!(dual)
        termination_status(dual) == MOI.OPTIMAL ||
            error("Traffic equilibrium dual hour $h: $(termination_status(dual))")
        active = [p for p in 1:P if time[p] + sum(value(λ[a]) for a in I.paths[p]) -
                                   value(ϕ[I.pod[p]]) <= 1e-6]
        return (paths=active, by_od=[intersect(ps, active) for ps in I.podl],
                by_road=[intersect(ps, active) for ps in I.thr],
                free=free, delay=objective_value(dual))
    end
end

# ----------------------------------------------------------------------------
# add_stage!: adds ONE planning period (Eq. 2-44, with xi_t fixed to scenario sc)
# to an existing JuMP model.  The incoming state st0 = (z0, Cc0, Ce0, Cv0) may be
# numbers, bit expressions or the outgoing variables of another period, so the same
# code builds (i) a single stage for RDDP and (ii) the extensive form of a scenario
# tree for the exact C&CG solver.  All variables are anonymous (no name clashes).
# ----------------------------------------------------------------------------
function add_stage!(m, I, t, sc::Scen, st0)
    cfg = I.cfg; A = I.A; n = length(I.tois)
    z0, Cc0, Ce0, Cv0 = st0

    # ---- investment (Eq.37-44; y-binaries eliminated: E <= Ebar*z_{t-1}, Eq.39-40)
    Z  = @variable(m, [1:A], Bin)
    Cc = @variable(m, [1:A], lower_bound=0, upper_bound=I.Cmax.c)
    Ce = @variable(m, [1:A], lower_bound=0, upper_bound=I.Cmax.e)
    Cv = @variable(m, [1:A], lower_bound=0, upper_bound=I.Cmax.v)
    Ec = @variable(m, [1:A], lower_bound=0); Ee = @variable(m, [1:A], lower_bound=0)
    Ev = @variable(m, [1:A], lower_bound=0)
    # capacities on the binarisation grid (multiples of cfg.step), identical in every solver path
    kc = @variable(m, [1:A], Int); ke = @variable(m, [1:A], Int); kv = @variable(m, [1:A], Int)
    @constraint(m, [a=1:A], Cc[a] == cfg.step*kc[a])
    @constraint(m, [a=1:A], Ce[a] == cfg.step*ke[a])
    @constraint(m, [a=1:A], Cv[a] == cfg.step*kv[a])
    @constraint(m, [a=1:A], Z[a] >= z0[a])                                   # Eq.38
    @constraint(m, [a=1:A], Ec[a] <= EBAR.c*z0[a])                           # Eq.39,40,44
    @constraint(m, [a=1:A], Ee[a] <= EBAR.e*z0[a])
    @constraint(m, [a=1:A], Ev[a] <= EBAR.v*z0[a])
    @constraint(m, [a=1:A], Cc[a] == Cc0[a] + (Z[a]-z0[a])*C0.c + Ec[a])     # Eq.41
    @constraint(m, [a=1:A], Ce[a] == Ce0[a] + (Z[a]-z0[a])*C0.e + Ee[a])     # Eq.42
    @constraint(m, [a=1:A], Cv[a] == Cv0[a] + (Z[a]-z0[a])*C0.v + Ev[a])     # Eq.43
    inv = sum(COST.rvc*(Z[a]-z0[a]) + COST.fc*Ec[a] + COST.es*Ee[a] + COST.pv*Ev[a] for a in 1:A)  # Eq.2
    man = COST.man*sum(Z)                                                    # Eq.3
    capC = cfg.cap_mode == :current ? Cc : [Cc0[a] + Ec[a] for a in 1:A]
    capE = cfg.cap_mode == :current ? Ce : [Ce0[a] + Ee[a] for a in 1:A]

    # ---- operation variables
    NB = I.nbus; L = length(LINES); G = length(DRES); P = length(I.paths); O = length(OD_PAIRS)
    Pb  = @variable(m, [1:n], lower_bound=0, upper_bound=PBU)
    Qb  = @variable(m, [1:n], lower_bound=0, upper_bound=0.3*PBU)
    Pw  = @variable(m, [1:G,1:n], lower_bound=0)
    Rv  = @variable(m, [1:A,1:n], lower_bound=0)
    Pcs = @variable(m, [1:A,1:n], lower_bound=0)
    Pec = @variable(m, [1:A,1:n], lower_bound=0); Ped = @variable(m, [1:A,1:n], lower_bound=0)
    vc  = @variable(m, [1:A,1:n], Bin);           vd  = @variable(m, [1:A,1:n], Bin)
    s   = @variable(m, [1:A,1:n], lower_bound=0)
    Pf  = @variable(m, [1:L,1:n]);                Qf  = @variable(m, [1:L,1:n])
    V   = @variable(m, [1:NB,1:n], lower_bound=VMIN, upper_bound=VMAX)
    dpp = @variable(m, [1:NB,1:n], lower_bound=0); dpm = @variable(m, [1:NB,1:n], lower_bound=0)
    dqp = @variable(m, [1:NB,1:n], lower_bound=0); dqm = @variable(m, [1:NB,1:n], lower_bound=0)
    xch = @variable(m, [1:20,1:n], lower_bound=0); xun = @variable(m, [1:20,1:n], lower_bound=0)
    multiplier = t == 1 ? 1.0 : sc.td
    traffic = cfg.compact_traffic ?
              [traffic_equilibrium(I, h, multiplier) for (_, h) in I.tois] :
              fill((paths=1:P, by_od=I.podl, by_road=I.thr), n)
    fch = [@variable(m, [p in traffic[j].paths], lower_bound=0) for j in 1:n]
    fun = [@variable(m, [p in traffic[j].paths], lower_bound=0) for j in 1:n]
    if !cfg.compact_traffic
        lam = @variable(m, [1:A,1:n], lower_bound=0)
        phch = @variable(m, [1:O,1:n])
        phun = @variable(m, [1:O,1:n])
    end
    fpcs = @variable(m, [1:A,1:n], lower_bound=0)

    ope = AffExpr(0.0)                       # total operation cost (sum of the parts below)
    part = Dict(k => AffExpr(0.0) for k in (:substation, :curtail, :imbalance, :travel))
    addc!(k, e) = (add_to_expression!(part[k], e); add_to_expression!(ope, e))
    vb2 = 1000.0 * cfg.vbase_kV^2 * VNOM
    Pmax_dre = SW/sqrt(1+TANG^2)
    γ = cfg.gamma
    for j in 1:n
        d, h = I.tois[j]
        # ---------- PDN (Eq.18-31)
        for g in 1:G
            bus, cap, kind = DRES[g]
            pu = kind == :wt ? WT_PU[h,d] : PV_PU[h,d]
            Aw = (t == 1 ? 1.0 : sc.dre) * cap * pu * sc.xi[g,j]              # Eq.46,50-51
            @constraint(m, Pw[g,j] <= Aw)                                      # Eq.21
            @constraint(m, Pw[g,j] <= Pmax_dre)                                # Eq.22-23 (Q = tan*P)
            addc!(:curtail, COST.curt*(Aw - Pw[g,j]))
        end
        for a in 1:A
            pvpu = PV_PU[h,d]*sc.zeta[a,j]
            @constraint(m, Rv[a,j] <= Cv[a]*pvpu)                              # Eq.24,47
            addc!(:curtail, COST.curt*(Cv[a]*pvpu - Rv[a,j]))
            @constraint(m, Pcs[a,j] <= capC[a])                                # Eq.33
            @constraint(m, Pec[a,j] <= BESS_P*vc[a,j])   # Eq.19
            @constraint(m, Ped[a,j] <= BESS_P*vd[a,j])
            @constraint(m, vc[a,j] + vd[a,j] <= 1)
            @constraint(m, Pec[a,j] <= capE[a])
            @constraint(m, Ped[a,j] <= capE[a])
            @constraint(m, s[a,j] <= capE[a])                                  # Eq.20 (energy form)
        end
        for i in 1:NB
            LD = LOAD_KW[h,d]/NB; QD = cfg.load_tanphi*LD
            wi = I.dre_at[i]; ai = I.sta_at[i]
            @constraint(m,   # Eq.28 (Pn from Eq.25)
                (i==1 ? Pb[j] : 0.0) + sum(Pf[l,j] for l in I.lin[i]; init=0.0) +
                sum(Pw[g,j] for g in wi; init=0.0) + dpp[i,j] - dpm[i,j] ==
                sum(Pf[l,j] for l in I.lout[i]; init=0.0) +
                sum(Pcs[a,j] + Pec[a,j] - Ped[a,j] - Rv[a,j] for a in ai; init=0.0) + LD)
            @constraint(m,   # Eq.29
                (i==1 ? Qb[j] : 0.0) + sum(Qf[l,j] for l in I.lin[i]; init=0.0) +
                sum(TANG*Pw[g,j] for g in wi; init=0.0) ==
                sum(Qf[l,j] for l in I.lout[i]; init=0.0) + dqp[i,j] - dqm[i,j] + QD)
        end
        for l in 1:L
            f, to, r, x, cap = LINES[l]
            @constraint(m, -cap <= Pf[l,j] <= cap)    # Eq.30 bounds active flow only
            @constraint(m, V[f,j] - V[to,j] == (Pf[l,j]*r + Qf[l,j]*x)/vb2)                   # Eq.26-27
        end
        addc!(:substation, COST.su*Pb[j])
        addc!(:imbalance, COST.unb*(sum(dpp[:,j]) + sum(dpm[:,j]) + sum(dqp[:,j]) + sum(dqm[:,j])))
        # ---------- UTN (Eq.6-17) and coupling (Eq.32-36)
        D = multiplier .* OD_FLOW[h, :]                                     # Eq.45
        tr = traffic[j]
        for o in 1:O
            @constraint(m, sum(fch[j][p] for p in tr.by_od[o]) == γ*D[o])       # Eq.8
            @constraint(m, sum(fun[j][p] for p in tr.by_od[o]) == (1-γ)*D[o])   # Eq.9
        end
        for b in 1:A
            ps = tr.by_road[b]
            @constraint(m, xch[b,j] == sum(fch[j][p] for p in ps; init=0.0))     # Eq.11
            @constraint(m, xun[b,j] == sum(fun[j][p] for p in ps; init=0.0))     # Eq.12
            @constraint(m, xch[b,j] + xun[b,j] <= ROAD_CAP[b])                  # Eq.6-7
        end
        free_time = sum(ROAD_H0[b]*(xch[b,j]+xun[b,j]) for b in 1:A)
        if cfg.compact_traffic
            @constraint(m, free_time == tr.free)
            delay = tr.delay
        else
            for p in tr.paths
                o = I.pod[p]
                pc = sum(ROAD_H0[b] + lam[b,j] for b in I.paths[p])
                @constraint(m, phch[o,j] <= pc)
                @constraint(m, phun[o,j] <= pc)
            end
            delay = sum(ROAD_CAP[b]*lam[b,j] for b in 1:A)
            @constraint(m, sum(γ*D[o]*phch[o,j] + (1-γ)*D[o]*phun[o,j] for o in 1:O) ==
                           free_time + delay)                                  # Eq.17
        end
        @constraint(m, sum(fpcs[:,j]) == γ*sum(D))                            # Eq.34
        for a in 1:A
            @constraint(m, Pcs[a,j] == cfg.dp*fpcs[a,j])                       # Eq.32
            @constraint(m, fpcs[a,j] <= sum(fch[j][p] for p in tr.by_road[a]; init=0.0)) # Eq.35
        end
        for p in tr.paths
            @constraint(m, fch[j][p] <= sum(fpcs[a,j] for a in I.paths[p]))      # Eq.36
        end
        addc!(:travel, COST.fr*free_time + COST.ja*delay)                      # Eq.5, using complementarity
    end
    # BESS SOC, cyclic per typical day (Eq.20)
    for g in I.groups, a in 1:A, (k, j) in enumerate(g)
        jp = g[k == 1 ? length(g) : k-1]
        @constraint(m, s[a,j] == s[a,jp] + ETA_C*Pec[a,j] - Ped[a,j]/ETA_D)
    end
    disc = 1/(1+cfg.sigma)^(t-1)                                               # Eq.1
    stage_cost = disc*(inv + man + cfg.amp*ope)
    return (Z=Z, Cc=Cc, Ce=Ce, Cv=Cv, Ec=Ec, Ee=Ee, Ev=Ev, stage_cost=stage_cost, inv=inv,
            man=man, ope=ope, part=part, disc=disc, dpp=dpp, dpm=dpm, dqp=dqp, dqm=dqm,
            Pw=Pw, Pcs=Pcs, Pb=Pb, xch=xch, fpcs=fpcs, Rv=Rv, Pec=Pec, Ped=Ped, soc=s,
            Pf=Pf, Qf=Qf, V=V)
end

# ----------------------------------------------------------------------------
# Single-stage MILP for RDDP:  Q_t(x_{t-1}; xi_t) + lower approximation of Q_{t+1}
#   incoming state = bit variables bin_in (fixed per solve, freed for Lagrangian duals)
#   outgoing state = bit variables bout (binarised, SDDiP-style, Sec. III-A)
# ----------------------------------------------------------------------------
function build_stage(I, t, sc::Scen; cuts::Vector{Cut}=Cut[])
    cfg = I.cfg; T = cfg.T; terminal = (t == T)
    m = new_model(cfg)
    bin_in = @variable(m, [1:I.nbit], Bin)
    X = add_stage!(m, I, t, sc, unpack(I, bin_in))
    bout = nothing; θ = nothing
    if !terminal
        bout = @variable(m, [1:I.nbit], Bin)
        zb, Ccb, Ceb, Cvb = unpack(I, bout)
        @constraint(m, [a=1:I.A], X.Z[a] == zb[a])
        @constraint(m, [a=1:I.A], X.Cc[a] == Ccb[a])
        @constraint(m, [a=1:I.A], X.Ce[a] == Ceb[a])
        @constraint(m, [a=1:I.A], X.Cv[a] == Cvb[a])
        θ = @variable(m, lower_bound=0)                          # cost-to-go >= 0
        for c in cuts; add_cut!(m, θ, bout, c); end
    end
    obj = θ === nothing ? X.stage_cost : X.stage_cost + θ
    @objective(m, Min, obj)
    return merge(X, (m=m, bin_in=bin_in, bout=bout, θ=θ, obj=obj))
end

# solve; returns (ok, objective, bound)
function solve_stage(S)
    optimize!(S.m)
    st = termination_status(S.m)
    ok = has_values(S.m) && primal_status(S.m) == MOI.FEASIBLE_POINT
    obj = ok ? objective_value(S.m) : Inf
    bnd = objective_bound(S.m)
    return (ok=ok, obj=obj, bound=bnd, status=st)
end

function get_state(I, S)
    r(x) = round.(value.(x) ./ I.cfg.step) .* I.cfg.step      # capacities are exact multiples of step
    return (z = round.(value.(S.Z)), Cc = r(S.Cc), Ce = r(S.Ce), Cv = r(S.Cv))
end

# ----------------------------------------------------------------------------
# Model cache: one MILP (+ one LP relaxation for starting duals) per (stage, scenario).
# The incoming state is a vector of bit variables that are FIXED per solve, so the
# model is built once and only gets new cuts appended (warm, cheap re-solves).
# ----------------------------------------------------------------------------
mutable struct SM
    S::NamedTuple
    L::NamedTuple
    nc::Int
end

function get_sm!(cache, I, t, k, sc)
    key = (t, k)
    haskey(cache, key) && return cache[key]
    S = build_stage(I, t, sc)
    L = build_stage(I, t, sc); relax_integrality(L.m)
    cache[key] = SM(S, L, 0)
end

function sync!(sm::SM, cuts::Vector{Cut})
    sm.S.θ === nothing && return
    for i in sm.nc+1:length(cuts), X in (sm.S, sm.L)
        c = cuts[i]
        add_cut!(X.m, X.θ, X.bout, c)
    end
    sm.nc = length(cuts)
end

function fix_state!(X, xbits)
    for j in eachindex(xbits); fix(X.bin_in[j], xbits[j]; force=true); end
end

function unfix_state!(X)
    for v in X.bin_in; is_fixed(v) && unfix(v); end
end

# ----------------------------------------------------------------------------
# Lagrangian cut (Eq.60):  Q_t(x) >= Θ(π) + π'x   for every binarised x
#   Θ(π) = min_{β,x_t,y_t} stage_obj − π'β  (β free binary copy of x_{t-1})
# Only objective_bound is used, so the cut is valid even if a MIP is stopped early.
# ----------------------------------------------------------------------------
function lagrangian_cut(I, sm::SM, xbar)
    nb = I.nbit
    # (a) strengthened-Benders start: LP duals of the state-fixing constraints
    fix_state!(sm.L, xbar); optimize!(sm.L.m)
    π0 = has_duals(sm.L.m) ? [reduced_cost(sm.L.bin_in[j]) for j in 1:nb] : zeros(nb)
    # (b) Kelley cutting planes on the concave dual with a shrinking trust box
    S = sm.S; unfix_state!(S)
    base = S.obj
    best = (L=-Inf, π=π0, Θ=-Inf)
    π = copy(π0); Δ = 0.5*(1 + maximum(abs, π0))
    hist = Tuple{Vector{Float64},Float64,Vector{Float64}}[]
    sb = nothing
    for it in 0:I.cfg.lag_iters
        set_objective_function(S.m, base - dot(π, S.bin_in))
        optimize!(S.m)
        (has_values(S.m) && primal_status(S.m) == MOI.FEASIBLE_POINT) || break
        Θ = objective_bound(S.m); β = round.(value.(S.bin_in))
        isfinite(Θ) || break
        L = Θ + dot(π, xbar)
        push!(hist, (copy(π), objective_value(S.m) + dot(π, xbar), xbar .- β))
        it == 0 && (sb = Cut(Θ, copy(π)))               # strengthened-Benders cut (LP-dual slopes)
        if L > best.L + 1e-9; best = (L=L, π=copy(π), Θ=Θ); else Δ *= 0.5; end
        it == I.cfg.lag_iters && break
        mm = Model(HiGHS.Optimizer); set_silent(mm)
        @variable(mm, p[1:nb]); @variable(mm, th)
        @constraint(mm, p .<= best.π .+ Δ); @constraint(mm, p .>= best.π .- Δ)
        for (pk, Lk, gk) in hist; @constraint(mm, th <= Lk + dot(gk, p .- pk)); end
        @objective(mm, Max, th); optimize!(mm)
        termination_status(mm) == MOI.OPTIMAL || break
        π = value.(p)
    end
    set_objective_function(S.m, base)
    # Return BOTH cuts: the strengthened-Benders cut keeps the LP-dual slopes, which carry
    # global information about Q_t, while the Lagrangian cut is tighter only near xbar.
    out = Cut[]
    sb === nothing || push!(out, sb)
    (isfinite(best.Θ) && (sb === nothing || best.π != sb.pi)) && push!(out, Cut(best.Θ, best.π))
    return out, best.L
end

function add_cut!(m, θ, bits, c)
    if c.alpha == Inf
        @constraint(m, dot(c.pi, bits) <= count(>(0), c.pi) - 1)
    else
        @constraint(m, θ >= c.alpha + dot(c.pi, bits))
    end
end

function integer_cut(xbar, v)
    n1 = count(>(0.5), xbar)
    v == Inf && return Cut(Inf, [x > 0.5 ? 1.0 : -1.0 for x in xbar])
    return Cut(v*(1 - n1), [x > 0.5 ? v : -v for x in xbar])
end

# ----------------------------------------------------------------------------
# RDDP on a finite uncertainty set (T = 3 or any T; the policy tree is enumerated,
# so cost grows like |Phi|^(T-1) -- intended for the paper's T = 3).
#   LB  : root bound of stage 1 with Lagrangian cuts (valid for the finite set)
#   UB  : exact cost of the current nonanticipative policy, max over the tree
# Cuts are generated at every visited node (post-order), worst xi chosen per node.
# ----------------------------------------------------------------------------
function rddp(I; max_iter=40, tol=1e-3, outdir=nothing, log=true)
    T = I.cfg.T
    cuts  = [Cut[] for _ in 1:T+1]
    Phi   = [scen_set(I, t) for t in 1:T]
    cache = Dict{Tuple{Int,Int},SM}()
    x0 = initial_state(I)
    hist = NamedTuple[]
    bestUB = Inf; bestLB = -Inf; bestx1 = x0; nsolve = Ref(0)
    worstmip = Ref(0.0); nonopt = Ref(0)

    function refine!(t, sm, xbits)
        for _ in 1:I.cfg.refine_rounds
            sync!(sm, cuts[t+1]); fix_state!(sm.S, xbits)
            r = solve_stage(sm.S); nsolve[] += 1; r.ok || return
            θv = value(sm.S.θ); xb2 = encode(I, get_state(I, sm.S))
            best = nothing
            for (k2, sc2) in enumerate(Phi[t+1])
                sm2 = get_sm!(cache, I, t+1, k2, sc2); sync!(sm2, cuts[t+2])
                fix_state!(sm2.S, xb2); r2 = solve_stage(sm2.S); nsolve[] += 1
                r2.ok || continue
                (best === nothing || r2.obj > best.obj) && (best = (obj=r2.obj, bnd=r2.bound, sm=sm2))
            end
            best === nothing && return
            best.obj <= θv + I.cfg.refine_tol*max(abs(best.obj), 1.0) && return   # exact at argmin
            cs, _ = lagrangian_cut(I, best.sm, xb2)
            append!(cuts[t+1], cs); push!(cuts[t+1], integer_cut(xb2, max(best.bnd, 0.0)))
        end
    end

    function visit(t, xprev, prefix, rows)
        xbits = encode(I, xprev)
        res = []
        for (k, sc) in enumerate(Phi[t])
            sm = get_sm!(cache, I, t, k, sc); sync!(sm, cuts[t+1])
            fix_state!(sm.S, xbits); r = solve_stage(sm.S); nsolve[] += 1
            if !r.ok
                r.status == MOI.INFEASIBLE ||
                    error("No incumbent at stage $t, scenario $(sc.name): $(r.status)")
                # Infeasibility is specific to this incoming binary state. A
                # no-good cut excludes it from the preceding stage.
                push!(cuts[t], integer_cut(xbits, Inf))
                return Inf
            end
            worstmip[] = max(worstmip[], (r.obj - r.bound)/max(abs(r.obj),1.0)); r.status == MOI.OPTIMAL || (nonopt[] += 1)
            x = get_state(I, sm.S)
            cst = value(sm.S.stage_cost)
            path = prefix * " > " * sc.name
            child = t < T ? visit(t+1, x, path, rows) : 0.0
            push!(rows, policy_row(t, path, xprev, x, sm.S, child, r.status))
            push!(res, (k=k, obj=r.obj, bnd=r.bound, cost=cst, tot=cst+child, x=x, sm=sm))
        end
        isempty(res) && error("stage $t infeasible for every scenario")
        # Inner refinement at stage T-1 nodes: re-solve, evaluate the true (terminal) worst
        # case at the new argmin x_t, cut there, repeat until the cut model is exact at its
        # own argmin.  This stops the "chase" over many near-equivalent states that kept the
        # plain backward pass stalled (LB stuck at ~4 % gap).
        if t >= 2 && t == T-1 && I.cfg.refine_rounds > 0
            for q in res; refine!(t, q.sm, xbits); end
        end
        if t >= 2
            # BACKWARD step at this node: the children have just added cuts to cuts[t+1],
            # so every model is re-synchronised and re-solved before its cut is computed
            # (otherwise the cut would be built from a stale, weaker future approximation).
            fresh = map(res) do q
                sync!(q.sm, cuts[t+1]); fix_state!(q.sm.S, xbits)
                r = solve_stage(q.sm.S); nsolve[] += 1
                (q=q, bnd=r.ok ? r.bound : 0.0, obj=r.ok ? r.obj : -Inf)
            end
            # Q_t(x) = max_xi Q_t(x; xi): a cut from ANY scenario is valid.  Stage-2 has a
            # single node per iteration, so all scenarios are cut; deeper nodes: worst only.
            sel = t == 2 ? fresh : [fresh[argmax([f.obj for f in fresh])]]
            for f in sel
                cs, Lval = lagrangian_cut(I, f.q.sm, xbits)
                I.cfg.verbose_cuts && @printf("    cut t=%d %-18s node=%.1f  lagr=%.1f  fwd_obj=%.1f
", t, Phi[t][f.q.k].name, f.bnd, Lval, f.q.obj)
                append!(cuts[t], cs)
                push!(cuts[t], integer_cut(xbits, max(f.bnd, 0.0)))   # tight at xbar
            end
        end
        return maximum(q.tot for q in res)
    end

    max_iter > 0 || throw(ArgumentError("max_iter must be positive"))
    for it in 1:max_iter
        t0 = time(); ns0 = nsolve[]
        # stage 1 with the current cuts -> LB and first-stage decision
        sc1 = Phi[1][1]; sm1 = get_sm!(cache, I, 1, 1, sc1); sync!(sm1, cuts[2])
        fix_state!(sm1.S, encode(I, x0)); r1 = solve_stage(sm1.S); nsolve[] += 1
        r1.ok || error("Root solve returned no feasible incumbent: $(r1.status)")
        LB = r1.bound; x1 = get_state(I, sm1.S); c1 = value(sm1.S.stage_cost)
        rows = NamedTuple[]
        sub = T == 1 ? 0.0 : visit(2, x1, sc1.name, rows)
        push!(rows, policy_row(1, sc1.name, x0, x1, sm1.S, sub, r1.status))
        UB = c1 + sub; UBcur = UB
        bestLB = max(bestLB, LB)
        if UB < bestUB
            bestUB = UB
            bestx1 = x1
            outdir === nothing || write_policy(joinpath(outdir, "policy_tree.csv"), rows)
        end
        gap = isfinite(bestUB) ? (bestUB - bestLB) / max(abs(bestUB), 1.0) : Inf
        push!(hist, (iter=it, LB=bestLB, UB=bestUB, gap=gap, x1=bestx1, secs=time()-t0, solves=nsolve[]-ns0))
        log && @printf("it%-3d LB=%.2f UB=%.2f gap=%.4f%% [root=%.0f c1=%.0f policyUB=%.0f] (%d MILP, %.0fs, worst MIP gap %.3g%%, non-opt %d)\n",
                       it, bestLB, bestUB, 100gap, r1.bound, c1, UBcur, nsolve[]-ns0, time()-t0, 100worstmip[], nonopt[])
        worstmip[] = 0.0; nonopt[] = 0; flush(stdout)
        if outdir !== nothing
            open(joinpath(outdir, "convergence.csv"), it == 1 ? "w" : "a") do io
                it == 1 && println(io, "iter,LB,UB,gap,seconds,milp_solves")
                @printf(io, "%d,%.4f,%.4f,%.8f,%.2f,%d\n", it, bestLB, bestUB, gap, time()-t0, nsolve[]-ns0)
            end
        end
        gap <= tol && break
    end
    return hist, cuts
end

# ----------------------------------------------------------------------------
# Evaluate the final policy on the whole finite tree and export every node
# (stage, scenario path, decisions, cost breakdown).  Returns (rows, value).
# ----------------------------------------------------------------------------
function policy_row(t, path, xprev, x, S, child, status)
    built = [a for a in eachindex(x.z) if x.z[a] > 0.5 && xprev.z[a] < 0.5]
    dC = x.Cc .- xprev.Cc
    dE = x.Ce .- xprev.Ce
    dV = x.Cv .- xprev.Cv
    expanded = [a for a in eachindex(x.z) if xprev.z[a] > 0.5 && dC[a]+dE[a]+dV[a] > 1e-6]
    cost = value(S.stage_cost)
    return (stage=t, path=path, new_stations=join(built, ";"),
            expanded=join(["$a(+$(dC[a])/+$(dE[a])/+$(dV[a]))" for a in expanded], ";"),
            capacities=join(["$a:$(x.Cc[a])/$(x.Ce[a])/$(x.Cv[a])" for a in eachindex(x.z) if x.z[a] > 0.5], ";"),
            inv=value(S.inv), man=value(S.man),
            substation=value(S.part[:substation]), curtail=value(S.part[:curtail]),
            imbalance=value(S.part[:imbalance]), travel=value(S.part[:travel]),
            disc_stage_cost=cost, cost_to_go=child, total_from_here=cost+child,
            mip_status=string(status))
end

function write_policy(path, rows)
    open(path, "w") do io
        println(io, join(keys(first(rows)), ","))
        for row in rows
            println(io, join(values(row), ","))
        end
    end
end

function evaluate_policy(I, cuts; csv=nothing)
    T = I.cfg.T
    Phi = [scen_set(I, t) for t in 1:T]
    rows = NamedTuple[]
    function rec(t, xprev, path)
        best = -Inf
        for sc in Phi[t]
            S = build_stage(I, t, sc; cuts=t < T ? cuts[t+1] : Cut[])
            fix_state!(S, encode(I, xprev))
            r = solve_stage(S)
            r.ok || error("Cannot evaluate stage $t, $(sc.name): $(r.status)")
            x = get_state(I, S)
            p = isempty(path) ? sc.name : path * " > " * sc.name
            child = t < T ? rec(t+1, x, p) : 0.0
            row = policy_row(t, p, xprev, x, S, child, r.status)
            push!(rows, row)
            best = max(best, row.total_from_here)
        end
        return best
    end
    v = rec(1, initial_state(I), "")
    csv === nothing || write_policy(csv, rows)
    return rows, v
end

# ----------------------------------------------------------------------------
# EXACT reference solver for the same finite tree: nested column-and-constraint
# generation on scenario paths (deterministic-equivalent over a growing sub-tree).
#   For a finite tree, min over non-anticipative policies of the max path cost equals
#   the nested min-max-min value, so:
#   LB = master over the sub-tree S (fewer paths  -> lower value, valid)
#   UB = c1(x1) + max_i V2(x1, xi2_i), with V2 solved exactly (two-stage robust MILP)
#   Paths that attain the UB are added to S until LB = UB (finite: the tree is finite).
# ----------------------------------------------------------------------------
costparts(X) = (inv=value(X.inv), man=value(X.man), substation=value(X.part[:substation]),
                curtail=value(X.part[:curtail]), imbalance=value(X.part[:imbalance]),
                travel=value(X.part[:travel]), disc_cost=value(X.stage_cost))
cstate(x) = (x.z, x.Cc, x.Ce, x.Cv)
vstate(X) = (X.Z, X.Cc, X.Ce, X.Cv)
vals(I, X) = get_state(I, X)

function solve_value2(I, Phi, x1, i)
    m = new_model(I.cfg)
    X2 = add_stage!(m, I, 2, Phi[2][i], cstate(x1))
    X3 = [add_stage!(m, I, 3, sc, vstate(X2)) for sc in Phi[3]]
    η = @variable(m)
    for X in X3; @constraint(m, η >= X2.stage_cost + X.stage_cost); end
    @objective(m, Min, η); optimize!(m)
    ok = has_values(m) && primal_status(m) == MOI.FEASIBLE_POINT
    status = termination_status(m)
    status == MOI.INFEASIBLE && return nothing
    ok || error("No incumbent for scenario $(Phi[2][i].name): $status")
    c2 = value(X2.stage_cost); c3 = [value(X.stage_cost) for X in X3]
    return (obj=c2 + maximum(c3), bound=objective_bound(m), c2=c2, c3=c3,
            jstar=argmax(c3), x2=vals(I, X2), x3=[vals(I, X) for X in X3],
            parts2=costparts(X2), parts3=[costparts(X) for X in X3], status=termination_status(m))
end

function ccg_exact(I; max_iter=30, tol=1e-4, outdir=nothing, log=true)
    Phi = [scen_set(I, t) for t in 1:I.cfg.T]
    I.cfg.T == 3 || error("ccg_exact is written for T = 3")
    x0 = initial_state(I)
    hi = findfirst(sc -> sc.name == "td3_dre1_adv", Phi[2])
    S = [(something(hi, 1), something(hi, 1))]           # start with the (likely) LS-oriented path
    bestUB = Inf; bestLB = -Inf; best = nothing; hist = NamedTuple[]
    for it in 1:max_iter
        t0 = time()
        m = new_model(I.cfg)
        X1 = add_stage!(m, I, 1, Phi[1][1], cstate(x0))
        X2 = Dict(i => add_stage!(m, I, 2, Phi[2][i], vstate(X1)) for i in unique(first.(S)))
        η = @variable(m)
        for (i, j) in S
            X3 = add_stage!(m, I, 3, Phi[3][j], vstate(X2[i]))
            @constraint(m, η >= X1.stage_cost + X2[i].stage_cost + X3.stage_cost)
        end
        @objective(m, Min, η); optimize!(m)
        has_values(m) && primal_status(m) == MOI.FEASIBLE_POINT ||
            error("Scenario master returned no feasible incumbent: $(termination_status(m))")
        LB = objective_bound(m); x1 = vals(I, X1); c1 = value(X1.stage_cost); p1 = costparts(X1)
        # exact worst case of x1 over the whole tree
        V = [solve_value2(I, Phi, x1, i) for i in eachindex(Phi[2])]
        infeasible = findall(isnothing, V)
        UB = isempty(infeasible) ? c1 + maximum(v.obj for v in V) : Inf
        bestLB = max(bestLB, LB)
        if UB < bestUB; bestUB = UB; best = (x1=x1, c1=c1, p1=p1, V=V); end
        gap = isfinite(bestUB) ? (bestUB - bestLB) / max(abs(bestUB), 1.0) : Inf
        if isempty(infeasible)
            best_scenario = argmax([v.obj for v in V])
            newpaths = [(best_scenario, j) for j in eachindex(Phi[3])
                        if V[best_scenario].c2 + V[best_scenario].c3[j] >=
                           V[best_scenario].obj - 1e-6 * abs(V[best_scenario].obj) && !((best_scenario, j) in S)]
            if isempty(newpaths) && gap > tol
                # The current maximizer may already be in the master while an
                # omitted terminal branch changes the best stage-2 decision.
                newpaths = [(i, j) for i in eachindex(Phi[2]) for j in eachindex(Phi[3])
                            if !((i, j) in S)]
            end
            worst = Phi[2][best_scenario].name * " > " * Phi[3][V[best_scenario].jstar].name
        else
            newpaths = [(i, j) for i in infeasible for j in eachindex(Phi[3]) if !((i, j) in S)]
            worst = "infeasible recourse"
        end
        push!(hist, (iter=it, LB=bestLB, UB=bestUB, gap=gap, paths=length(S), secs=time()-t0))
        log && @printf("ccg it%-3d LB=%.2f UB=%.2f gap=%.5f%% paths=%d worst=%s (%.0fs, master %s)\n",
                       it, bestLB, bestUB, 100gap, length(S), worst, time()-t0, termination_status(m))
        flush(stdout)
        if outdir !== nothing
            open(joinpath(outdir, "ccg_convergence.csv"), it == 1 ? "w" : "a") do io
                it == 1 && println(io, "iter,LB,UB,gap,paths,seconds")
                @printf(io, "%d,%.4f,%.4f,%.8f,%d,%.2f
", it, bestLB, bestUB, gap, length(S), time()-t0)
            end
        end
        (gap <= tol || isempty(newpaths)) && break
        append!(S, newpaths)
    end
    return hist, best, Phi
end

function report_state(I, x; io=stdout)
    for a in 1:I.A
        x.z[a] > 0.5 || continue
        @printf(io, "  road %2d  FCS=%g kW  BESS=%g capacity  PV=%g kW\n", a, x.Cc[a], x.Ce[a], x.Cv[a])
    end
end

end # module
