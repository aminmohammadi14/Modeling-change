# Calculate paper checks and, when explicitly requested, run a diagnostic instance.
include(joinpath(@__DIR__, "REVCS33.jl"))
using .REVCS33, JuMP
const R = REVCS33

function write_table(path, header, rows)
    open(path, "w") do io
        println(io, join(header, ","))
        for row in rows
            println(io, join(row, ","))
        end
    end
end

function audit(out)
    wt = sum(cap for (_, cap, kind) in R.DRES if kind == :wt)
    pv = sum(cap for (_, cap, kind) in R.DRES if kind == :pv)
    charge = vec(sum(R.OD_FLOW; dims=2)) * R.Cfg().gamma
    available = wt .* R.WT_PU .+ pv .* R.PV_PU
    inputs = [(d, h, charge[h], R.LOAD_KW[h,d], wt*R.WT_PU[h,d],
               pv*R.PV_PU[h,d], available[h,d]) for d in 1:4 for h in 1:24]
    write_table(joinpath(out, "appendix_hourly.csv"),
        ("day", "hour", "charge_vehicles", "load_kw", "wind_available_kw",
         "pv_available_kw", "dre_available_kw"), inputs)

    roads = [(r, from, to, R.ROAD_BUS[r], R.ROAD_CAP[r], R.ROAD_H0[r], Int(r in R.EXISTING))
             for (r, (from, to)) in enumerate(R.ROAD_NODES)]
    write_table(joinpath(out, "roads.csv"),
        ("road", "from", "to", "bus", "capacity", "free_minutes", "existing"), roads)

    rows = Tuple[]
    for (t, published) in ((2, (4040.40, 914.62, 2169.49, 1912.88)),
                           (3, (5339.15, 1208.60, 2944.32, 2596.05)))
        dre, td = R.GROWTH[:dre][t][2], R.GROWTH[:td][t][2]
        metrics = ("forecast_dre_nameplate_kw", "forecast_min_hourly_available_dre_kw",
                   "forecast_max_charging_kw", "forecast_min_charging_kw")
        computed = (dre*(wt+pv), dre*minimum(available), td*maximum(charge), td*minimum(charge))
        for (metric, reference, calculated) in zip(metrics, published, computed)
            push!(rows, ("II", t, metric, reference, calculated, calculated-reference,
                         startswith(metric, "forecast_dre") || occursin("available", metric) ?
                         "growth inferred from Table II" : "growth and 1 kWh per vehicle inferred from Table II"))
        end
        push!(rows, ("II", t, "forecast_min_wind_only_kw", published[2],
                     dre*wt*minimum(R.WT_PU), dre*wt*minimum(R.WT_PU)-published[2],
                     "minimum of wind profile only; excludes simultaneous PV"))
        push!(rows, ("II", t, "figure_9c_traffic_forecast_multiplier", t == 2 ? 1.4 : 1.85, td,
                     td-(t == 2 ? 1.4 : 1.85), "figure labels versus Table II implied traffic growth"))
        push!(rows, ("II", t, "figure_9d_dre_forecast_multiplier", t == 2 ? 1.4 : 1.90, dre,
                     dre-(t == 2 ? 1.4 : 1.90), "figure labels versus Table II implied DRE growth"))
        push!(rows, ("II", t, "forecast_max_hourly_available_dre_kw", "", dre*maximum(available), "",
                     "actual maximum of hourly profiles; cf. nameplate row"))
        # Eq. (4) charges only available production that is curtailed. A generous
        # upper bound assumes zero dispatch and every onsite PV at max capacity.
        dre_high = R.GROWTH[:dre][t][3]
        renewable_ceiling = dre_high * (wt*R.WT_RNG[3]*sum(R.WT_PU) +
                                        pv*R.PV_RNG[3]*sum(R.PV_PU))
        installed_onsite_ceiling = length(R.ROAD_CAP) * (R.C0.v + t*R.EBAR.v)
        renewable_ceiling += installed_onsite_ceiling * R.PV_RNG[3] * sum(R.PV_PU)
        rc_ceiling = R.COST.curt * renewable_ceiling
        rc_published = t == 2 ? 1441160.0 : 392280.0
        push!(rows, ("II", t, "unweighted_curtailment_cost_upper_bound_usd", rc_published,
                     rc_ceiling, rc_ceiling-rc_published, "generous Eq. 4 bound over the 96 published TOIs"))
    end
    avg_line = sum(line[5] for line in R.LINES) / length(R.LINES)
    push!(rows, ("II", "", "average_pdn_line_capacity_kw", 2735.92, avg_line,
                 avg_line-2735.92, "all 37 lines in appendix Table 11"))

    # Table I UTN formula: (7|B| + 2 sum |K_rs| + 2|O| + |A|) * |T_t|.
    # Infer count under equal K across OD pairs, as in the table's |O||K| notation.
    for (system, roads, od, stations, utn) in (("33P-12U", 20, 9, 20, 63744),
                                              ("54P-25U", 43, 17, 43, 202752))
        paths = (div(utn, 96) - 7roads - 2od - stations) ÷ 2
        push!(rows, ("I", "", "paths_" * system, "", paths, "", "inferred from printed UTN equation"))
        push!(rows, ("I", "", "paths_per_od_" * system, "", paths ÷ od, "", "assuming equal count per OD"))
    end
    write_table(joinpath(out, "paper_comparison.csv"),
        ("paper_table", "stage", "metric", "paper", "computed", "difference", "basis"), rows)
end

function diagnostic(out, cfg)
    isfile(joinpath(out, "diagnostic_settings.txt")) &&
        error("Choose a fresh results directory for each diagnostic run")
    I = R.build_inst(cfg)
    m = R.new_model(cfg)
    initial = R.initial_state(I)
    state = R.cstate(initial)
    stages = []
    for t in 1:cfg.T
        X = R.add_stage!(m, I, t, R.scen_nominal(I, t), state)
        push!(stages, X)
        state = R.vstate(X)
    end
    @objective(m, Min, sum(X.stage_cost for X in stages))
    optimize!(m)
    status = termination_status(m)
    feasible = primal_status(m) == R.MOI.FEASIBLE_POINT
    violations = feasible ? length(primal_feasibility_report(m; atol=1e-5)) : 0
    open(joinpath(out, "diagnostic_settings.txt"), "w") do io
        println(io, "scope=conditional deterministic forecast, 33P-12U")
        println(io, "status=", status)
        println(io, "lower_bound=", objective_bound(m))
        println(io, "solve_seconds=", solve_time(m))
        for field in fieldnames(R.Cfg)
            println(io, field, "=", getfield(cfg, field))
        end
        println(io, "stage_scenarios=", [(s.td, s.dre) for s in (R.scen_nominal(I,t) for t in 1:cfg.T)])
        if feasible
            println(io, "incumbent=", objective_value(m))
            println(io, "relative_gap=", relative_gap(m))
            println(io, "primal_violations_above_1e-5=", violations)
        end
    end
    println("Diagnostic solver status: ", status)
    feasible && violations == 0 || return

    inv = Tuple[]
    dispatch = Tuple[]
    traffic = Tuple[]
    costs = Tuple[]
    for (t, X) in enumerate(stages)
        sc = R.scen_nominal(I, t)
        x = R.get_state(I, X)
        for a in 1:I.A
            push!(inv, (t, a, Int(x.z[a]), Int(x.z[a] - initial.z[a]), x.Cc[a], x.Ce[a], x.Cv[a],
                        value(X.Ec[a]), value(X.Ee[a]), value(X.Ev[a])))
        end
        initial = x
        for (j, (d,h)) in enumerate(I.tois)
            wind = sum(value(X.Pw[g,j]) for g in eachindex(R.DRES) if R.DRES[g][3] == :wt)
            pv = sum(value(X.Pw[g,j]) for g in eachindex(R.DRES) if R.DRES[g][3] == :pv)
            onsite_pv = sum(value(X.Rv[a,j]) for a in 1:I.A)
            shedding = sum(value(X.dpp[b,j]) for b in 1:I.nbus)
            net2 = value(X.Pcs[2,j] + X.Pec[2,j] - X.Ped[2,j] - X.Rv[2,j])
            push!(dispatch, (t,d,h,R.LOAD_KW[h,d],value(X.Pb[j]),wind,pv,onsite_pv,
                             sum(value(X.Pcs[a,j]) for a in 1:I.A),shedding,net2,
                             value(X.Pcs[2,j]),value(X.Rv[2,j]),value(X.Ped[2,j]-X.Pec[2,j]),
                             value(X.soc[2,j]),R.DRES[1][2]*sc.dre*R.WT_PU[h,d],
                             minimum(value.(X.V[:,j])), maximum(value.(X.V[:,j]))))
            for a in 1:I.A
                push!(traffic, (t,d,h,a,value(X.xch[a,j]),value(X.fpcs[a,j])))
            end
        end
        parts = R.costparts(X)
        push!(costs, (t, values(parts)...))
    end
    write_table(joinpath(out, "investment.csv"),
        ("stage","road","exists","new","fcs_kw","bess_capacity","pv_kw","added_fcs_kw","added_bess","added_pv_kw"), inv)
    write_table(joinpath(out, "dispatch.csv"),
        ("stage","day","hour","load_kw","substation_kw","wind_kw","pv_kw","onsite_pv_kw",
         "fcs_kw","active_shortage_kw","road2_grid_kw","road2_fcs_kw","road2_pv_kw",
         "road2_bess_net_kw","road2_soc","bus4_wind_available_kw","min_voltage_pu","max_voltage_pu"), dispatch)
    write_table(joinpath(out, "charging_flow.csv"),
        ("stage","day","hour","road","traversing_vehicles","charging_vehicles"), traffic)
    write_table(joinpath(out, "diagnostic_costs.csv"), ("stage", keys(R.costparts(first(stages)))...), costs)
end

out = mkpath(length(ARGS) > 0 ? ARGS[1] : joinpath(@__DIR__, "out_audit"))
audit(out)
mode = length(ARGS) > 1 ? ARGS[2] : "--audit"
if mode in ("--diagnostic", "--diagnostic-smoke")
    cfg = R.Cfg(days=collect(1:4), hours=collect(1:24), threads=2,
                compact_traffic=get(ENV, "COMPACT_TRAFFIC", "1") == "1",
                time_limit=parse(Float64, get(ENV, "TIME_LIMIT", "180")),
                cap_mode=Symbol(get(ENV, "CAP_MODE", "current")))
    if mode == "--diagnostic-smoke"
        cfg.days = [1]
        cfg.hours = [9,14]
    end
    diagnostic(out, cfg)
elseif mode != "--audit"
    error("Use --audit, --diagnostic, or --diagnostic-smoke")
end
