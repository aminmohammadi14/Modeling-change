"""Plot appendix inputs and computed results from reproduce.jl or the tree runners."""
import argparse
import csv
import math
from pathlib import Path
import statistics

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


def read_rows(path):
    if not path.is_file():
        return []
    with path.open(encoding="utf-8", newline="") as stream:
        return list(csv.DictReader(stream))


def save(figure, out, name):
    figure.savefig(out / f"{name}.png", dpi=160, bbox_inches="tight")
    plt.close(figure)


def sequence(rows, key):
    return np.array([float(row[key]) for row in rows])


def plot_inputs(out):
    rows = read_rows(out / "appendix_hourly.csv")
    if not rows:
        return
    figure, (power, traffic) = plt.subplots(2, 1, figsize=(11, 5.6), sharex=True)
    hours = np.arange(1, 1 + len(rows))
    for field, label, color in [
        ("load_kw", "PDN demand", "#20242a"),
        ("wind_available_kw", "Available wind", "#346789"),
        ("pv_available_kw", "Available PV", "#d18b42"),
    ]:
        power.plot(hours, sequence(rows, field), label=label, color=color)
    traffic.plot(hours, sequence(rows, "charge_vehicles"), color="#405746")
    for axis in (power, traffic):
        for boundary in (24.5, 48.5, 72.5):
            axis.axvline(boundary, color="#c2c2c2", linewidth=1)
        axis.grid(alpha=0.18)
    power.legend(ncol=3)
    power.set_ylabel("Power (kW)")
    traffic.set_ylabel("EVs requiring charge")
    traffic.set_xlabel("Typical operation interval (h)")
    figure.suptitle("33P-12U inputs from appendix Tables 2–8")
    save(figure, out, "appendix_inputs")


def plot_dispatch(out):
    rows = read_rows(out / "dispatch.csv")
    if not rows:
        return
    hours = np.arange(1, len(rows) + 1)
    fig, ax = plt.subplots(figsize=(12, 4.5))
    ax.stackplot(hours, *(sequence(rows, k) for k in
                         ("substation_kw", "wind_kw", "pv_kw", "onsite_pv_kw", "active_shortage_kw")),
                 labels=("Substation", "Wind", "PDN PV", "Onsite PV", "Active shortfall"), alpha=0.75)
    ax.plot(hours, sequence(rows, "load_kw"), label="PDN load", color="#15191c", linewidth=1.2)
    ax.plot(hours, sequence(rows, "fcs_kw"), label="FCS load", color="#622377", linewidth=1.2)
    for idx, row in enumerate(rows[1:], start=1):
        if row["stage"] != rows[idx - 1]["stage"]:
            ax.axvline(idx + 0.5, color="#3d3d3d", linestyle="--", linewidth=0.8)
    ax.set(xlabel="Typical operation interval (h)", ylabel="Power (kW)",
           title="Dispatch under the deterministic forecast")
    ax.legend(ncol=4, loc="upper center", bbox_to_anchor=(0.5, -0.15))
    save(fig, out, "diagnostic_dispatch")

    day = [row for row in rows if row["stage"] == "3" and row["day"] == "1"]
    flow = [row for row in read_rows(out / "charging_flow.csv")
            if row["stage"] == "3" and row["day"] == "1"]
    if not day or not flow:
        return
    day_hours = sorted(int(row["hour"]) for row in day)
    road_ids = sorted({int(row["road"]) for row in flow})
    figures, axes = plt.subplots(2, 1, figsize=(11, 7.5), layout="constrained")
    values = {(int(row["road"]), int(row["hour"])): float(row["traversing_vehicles"]) for row in flow}
    matrix = [[values[(road, hour)] for hour in day_hours] for road in road_ids]
    heat = axes[0].imshow(matrix, aspect="auto", cmap="Blues", interpolation="nearest", vmin=0)
    axes[0].set_xticks(range(len(day_hours)), day_hours)
    axes[0].set_yticks(range(0, len(road_ids), 2), road_ids[::2])
    axes[0].set(xlabel="Hour", ylabel="Road", title="Flow of EVs requiring charge")
    figures.colorbar(heat, ax=axes[0], label="Vehicles per interval")
    for field, label in [
        ("road2_fcs_kw", "FCS"), ("road2_grid_kw", "From grid"),
        ("road2_pv_kw", "Onsite PV"), ("road2_bess_net_kw", "BESS net discharge"),
        ("bus4_wind_available_kw", "Available wind on bus 4")
    ]:
        axes[1].plot(day_hours, sequence(day, field), label=label)
    axes[1].set(xlabel="Hour", ylabel="Power (kW)", title="Road 2 power balance",
                xlim=(min(day_hours), max(day_hours)))
    soc = axes[1].twinx()
    soc.plot(day_hours, sequence(day, "road2_soc"), label="BESS state of charge",
             color="#4f5357", linestyle="--", linewidth=1.1)
    soc.set_ylabel("Stored energy (kWh in model)")
    power_lines, power_labels = axes[1].get_legend_handles_labels()
    soc_lines, soc_labels = soc.get_legend_handles_labels()
    axes[1].legend(power_lines + soc_lines, power_labels + soc_labels, ncol=3, fontsize=8)
    figures.suptitle("Stage 3, typical day 1 under the deterministic forecast")
    save(figures, out, "diagnostic_stage3_day1")

    flow_rows = read_rows(out / "charging_flow.csv")
    flow_by_road = {}
    for row in flow_rows:
        key = (int(row["stage"]), int(row["road"]))
        flow_by_road.setdefault(key, []).append(float(row["traversing_vehicles"]))
    inv = read_rows(out / "investment.csv")
    stages = sorted({int(row["stage"]) for row in inv})
    fig, axes = plt.subplots(2, len(stages), squeeze=False, figsize=(13, 5.8), sharex=True)
    for column, stage in enumerate(stages):
        data = [row for row in inv if int(row["stage"]) == stage]
        roads = sequence(data, "road")
        for offset, key, label in [
            (-0.25, "fcs_kw", "FCS (kW)"), (0, "pv_kw", "PV (kW)"),
            (0.25, "bess_capacity", "BESS (capacity)"),
        ]:
            axes[0, column].bar(roads + offset, sequence(data, key), width=0.24, label=label)
        axes[0, column].set_title(f"Stage {stage}")
        max_flow = [max(flow_by_road[stage, int(road)]) for road in roads]
        mean_flow = [statistics.mean(flow_by_road[stage, int(road)]) for road in roads]
        axes[1, column].plot(roads, max_flow, ".-", label="Maximum")
        axes[1, column].plot(roads, mean_flow, ".-", label="Mean")
        axes[1, column].set_xticks(roads[::2])
        axes[1, column].set_xlabel("Road")
    axes[0, 0].legend(fontsize=8)
    axes[1, 0].legend(fontsize=8)
    axes[1, 0].set_ylabel("Charging EV flow")
    fig.suptitle("Investment and road flow under the deterministic forecast")
    save(fig, out, "diagnostic_investment_and_flow")


# Schematic positions are for drawing only. Edges and couplings come from CSV.
NODE_XY = {
    1: (1, 3), 2: (2, 3), 3: (0, 2), 4: (1, 2), 5: (2, 2), 6: (3, 2),
    7: (0, 1), 8: (1, 1), 9: (2, 1), 10: (3, 1), 11: (1, 0), 12: (2, 0),
}


def plot_network(out):
    roads = read_rows(out / "roads.csv")
    if not roads:
        return
    investments = read_rows(out / "investment.csv")
    flows = read_rows(out / "charging_flow.csv")
    by_stage = {}
    for row in flows:
        key = (int(row["stage"]), int(row["road"]))
        by_stage.setdefault(key, []).append(float(row["traversing_vehicles"]))
    stages = sorted({int(row["stage"]) for row in investments})
    fig, axes = plt.subplots(1, len(stages) or 1, squeeze=False,
                             figsize=(4.4 * (len(stages) or 1), 4.5))
    for stage, axis in zip(stages or [None], axes[0]):
        stage_investment = {int(row["road"]): row for row in investments if int(row["stage"]) == stage}
        for row in roads:
            road = int(row["road"])
            x1, y1 = NODE_XY[int(row["from"])]
            x2, y2 = NODE_XY[int(row["to"])]
            installed = bool(int(row["existing"]))
            new = False
            expanded = False
            if stage is not None:
                plan = stage_investment[road]
                installed = bool(int(plan["exists"]))
                new = bool(int(plan["new"]))
                expanded = any(float(plan[key]) > 1e-6 for key in
                               ("added_fcs_kw", "added_bess", "added_pv_kw"))
            flow = statistics.mean(by_stage[stage, road]) if stage is not None else 0
            axis.plot([x1, x2], [y1, y2], color="#436d88" if flow >= 300 else "#aeb8c0",
                      linewidth=1.3 + flow/350, zorder=1)
            xm, ym = (x1 + x2)/2, (y1 + y2)/2
            if installed:
                marker_color = "#a84d3d" if new else "#245da8" if expanded else "#488360"
                axis.scatter([xm], [ym], marker="s", s=30, color=marker_color, zorder=2)
            axis.annotate(f"R{road}", (xm, ym), xytext=(3, 5), textcoords="offset points", fontsize=7, zorder=3)
        for node, (x, y) in NODE_XY.items():
            axis.scatter([x], [y], s=125, color="white", edgecolor="#2d3337", zorder=4)
            axis.text(x, y, str(node), size=7, ha="center", va="center", zorder=5)
        axis.set_title(f"Stage {stage}" if stage is not None else "Initial system")
        axis.set_aspect("equal")
        axis.set_axis_off()
    if stages:
        fig.suptitle("Road flows under the deterministic forecast")
        fig.text(0.5, 0.025,
                 "Line width shows mean charging EV flow. Station symbols are green for existing, blue for expanded, and red for newly built.",
                 ha="center", fontsize=8)
    else:
        fig.suptitle("33P-12U transportation network from Fig. 6")
        fig.text(0.5, 0.025, "Green squares mark existing charging stations.", ha="center", fontsize=8)
    save(fig, out, "diagnostic_road_network" if stages else "appendix_road_network")


def plot_tree_capacity(out):
    rows = read_rows(out / "ccg_policy.csv") or read_rows(out / "policy_tree.csv")
    if not rows:
        return
    worst = []
    stages = sorted({int(row["stage"]) for row in rows})
    for stage in stages:
        eligible = [r for r in rows if int(r["stage"]) == stage and
                    (not worst or r["path"].startswith(worst[-1]["path"] + " > "))]
        if stage == 2 and not eligible:
            # Older C&CG CSVs start the scenario prefix at stage 2.
            eligible = [r for r in rows if int(r["stage"]) == 2]
        if not eligible:
            raise ValueError(f"Missing policy rows for stage {stage}")
        worst.append(max(eligible, key=lambda r: float(r["total_from_here"])))
    fig, axes = plt.subplots(1, len(stages), squeeze=False, figsize=(4.2 * len(stages), 4))
    for stage, row, axis in zip(stages, worst, axes[0]):
        capacities = {}
        for record in filter(None, row["capacities"].split(";")):
            road, values = record.split(":")
            capacities[int(road)] = [float(x) for x in values.split("/")]
        roads = sorted(capacities)
        positions = np.arange(len(roads))
        for column, label in enumerate(("FCS (kW)", "BESS (capacity)", "PV (kW)")):
            axis.bar(positions + 0.25 * (column - 1), [capacities[road][column] for road in roads],
                     width=0.24, label=label)
        axis.set_xticks(positions, roads)
        axis.set(xlabel="Road", title=f"Stage {stage}")
    axes[0, 0].legend(fontsize=8)
    fig.suptitle("Capacities on the incumbent policy's highest-cost path")
    save(fig, out, "finite_tree_capacities")


def plot_tree(out):
    fig, ax = plt.subplots(figsize=(8, 4))
    plotted = False
    for label, file in [("RDDP variant", "convergence.csv"), ("Nested C&CG", "ccg_convergence.csv")]:
        rows = read_rows(out / file)
        if not rows:
            continue
        plotted = True
        ax.plot(sequence(rows, "iter"), sequence(rows, "LB"), ".-", label=f"{label} lower bound")
        ub = sequence(rows, "UB")
        ub[~np.isfinite(ub)] = math.nan
        ax.plot(sequence(rows, "iter"), ub, ".-", label=f"{label} policy upper bound")
    if plotted:
        ax.set(xlabel="Iteration", ylabel="Discounted cost ($)", title="Bounds for the modeled finite scenario tree")
        ax.legend()
        ax.grid(alpha=0.2)
        save(fig, out, "finite_tree_convergence")
    else:
        plt.close(fig)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("results", type=Path)
    args = parser.parse_args()
    plot_inputs(args.results)
    plot_dispatch(args.results)
    plot_network(args.results)
    plot_tree(args.results)
    plot_tree_capacity(args.results)
