# Data / structure checks against numbers printed in the paper (no solver needed).
using Test, JuMP
include(joinpath(@__DIR__, "..", "REVCS33.jl"))
using .REVCS33
const R = REVCS33

@testset "paper consistency" begin
    cfg = Cfg(); I = R.build_inst(cfg)
    @test length(R.LINES) == 37                      # Table I: |L| = 37 (3|L| term)
    @test length(R.DRES) == 10                       # |G| = 10
    @test I.A == 20 && length(R.OD_PAIRS) == 9
    @test length(I.paths) == 9*27                    # Table I: |O||K| = 243
    cap = sum(d[2] for d in R.DRES)
    # Table II (DRE) : 4040.40 / 5339.15 / 914.62 / 1208.60
    @test isapprox(1.4*cap, 4040.40; atol=0.01)
    @test isapprox(1.85*cap, 5339.15; atol=0.06)
    wt = [d[2] for d in R.DRES if d[3] == :wt]
    mn = minimum(sum(wt .* R.WT_PU[h, d]) for h in 1:24, d in 1:4)
    @test isapprox(1.4*mn, 914.62; atol=0.01)
    @test isapprox(1.85*mn, 1208.60; atol=0.01)
    # Table II (traffic): 2169.49 / 1912.88 / 2944.32 / 2596.05
    s = [sum(R.OD_FLOW[h, :]) for h in 1:24]
    @test isapprox(1.4*0.24*maximum(s), 2169.49; atol=0.02)
    @test isapprox(1.4*0.24*minimum(s), 1912.88; atol=0.02)
    @test isapprox(1.9*0.24*maximum(s), 2944.32; atol=0.02)
    @test isapprox(1.9*0.24*minimum(s), 2596.05; atol=0.02)
    # state encoding round trip
    x = R.initial_state(I); b = R.encode(I, x)
    y = R.unpack(I, b)
    @test y.Cc == x.Cc && y.Ce == x.Ce && y.Cv == x.Cv && y.z == x.z
end

@testset "known discrepancy" begin
    # The paper prints 2,735.92 kW as average PDN line capacity; the data appendix
    # (37 lines) gives 2535.92 -> exactly 200 kW lower.  Recorded, not "fixed".
    m = sum(l[5] for l in R.LINES)/length(R.LINES)
    @test isapprox(m, 2535.92; atol=0.01)
end

@testset "stage model + cut validity (HiGHS, 2 TOIs)" begin
    cfg = Cfg(days=[1], hours=[9,14], patterns=[:fc,:adv], time_limit=60.0, threads=2)
    I = R.build_inst(cfg); x0 = R.initial_state(I); xb = R.encode(I, x0)
    for t in 1:3
        S = R.build_stage(I, t, R.scen_nominal(I, t)); R.fix_state!(S, xb)
        r = R.solve_stage(S)
        @test r.ok
        scenario = R.scen_nominal(I, t)
        for (j, (_, h)) in enumerate(I.tois)
            target = cfg.gamma * scenario.td * sum(R.OD_FLOW[h, :])
            @test sum(value.(S.fpcs[:, j])) ≈ target atol=1e-7
        end
        rep = primal_feasibility_report(S.m; atol=1e-6)
        @test isempty(rep) || maximum(values(rep)) < 1e-6
    end
    # a Lagrangian / strengthened-Benders cut never exceeds the true value at its anchor
    sc = R.scen_set(I, 3)[1]
    sm = R.get_sm!(Dict{Tuple{Int,Int},R.SM}(), I, 3, 1, sc)
    x1 = (z=x0.z, Cc=x0.Cc .+ 100.0 .* x0.z, Ce=x0.Ce, Cv=x0.Cv)   # some reachable state
    xb1 = R.encode(I, x1)
    R.fix_state!(sm.S, xb1); v = R.solve_stage(sm.S).obj
    cs, L = R.lagrangian_cut(I, sm, xb1)
    for c in cs; @test c.alpha + c.pi' * xb1 <= v + 1e-3*abs(v); end
    ic = R.integer_cut(xb1, v)
    @test isapprox(ic.alpha + ic.pi' * xb1, v; rtol=1e-9)
    xo = copy(xb1); xo[2] = 1 - xo[2]                                  # Hamming distance 1
    @test ic.alpha + ic.pi' * xo <= 1e-6
end

@testset "printed charging capacity prevents serving with new stations alone" begin
    I = R.build_inst(Cfg(days=[1], hours=[9], cap_mode=:printed, threads=2))
    S = R.build_stage(I, 1, R.scen_nominal(I, 1))
    R.fix_state!(S, zeros(I.nbit))
    result = R.solve_stage(S)
    @test !result.ok
    @test result.status == R.MOI.INFEASIBLE
end

@testset "traffic equilibrium preprocessing preserves stage costs" begin
    results = Float64[]
    for compact in (false, true)
        cfg = Cfg(days=[1], hours=[9], time_limit=45.0, mip_gap=1e-6, threads=2,
                  compact_traffic=compact)
        I = R.build_inst(cfg)
        S = R.build_stage(I, 3, R.scen_nominal(I, 3))
        R.fix_state!(S, R.encode(I, R.initial_state(I)))
        result = R.solve_stage(S)
        @test result.ok
        @test result.status == R.MOI.OPTIMAL
        push!(results, result.obj)
    end
    @test isapprox(results...; rtol=2e-6)
end
