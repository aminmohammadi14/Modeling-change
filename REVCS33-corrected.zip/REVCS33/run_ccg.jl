include(joinpath(@__DIR__, "REVCS33.jl"))
using .REVCS33, Printf
preset = isempty(ARGS) ? "smoke" : ARGS[1]
cfg = preset == "smoke"  ? Cfg(days=[1], hours=[9,14], patterns=[:fc,:adv], time_limit=600.0, mip_gap=1e-5) :
      preset == "medium" ? Cfg(days=[1], hours=[3,9,14,19], patterns=[:fc,:adv], time_limit=1800.0, mip_gap=1e-5) :
      preset == "smoke_year" ? Cfg(days=[1], hours=[9,14], patterns=[:fc,:adv], time_limit=600.0, mip_gap=1e-5, amp=8760/2) :
      error("preset")
I = REVCS33.build_inst(cfg)
out = mktempdir(@__DIR__; prefix="out_ccg_" * preset * "_", cleanup=false)
println("Results: ", out)
hist, best, Phi = REVCS33.ccg_exact(I; tol=1e-4, outdir=out)
open(joinpath(out, "ccg_summary.txt"), "w") do io
    h = hist[end]
    @printf(io, "LB=%.4f\nUB=%.4f\ngap=%.6f%%\niterations=%d\npaths=%d\n", h.LB, h.UB, 100h.gap, h.iter, h.paths)
    println(io, "scope=restricted finite uncertainty set; certified_to_requested_tolerance=", isfinite(h.UB) && h.gap <= 1e-4)
    best === nothing && return
    @printf(io, "c1=%.4f\n", best.c1)
    for (i, v) in enumerate(best.V)
        @printf(io, "xi2=%-16s V2=%.2f c2=%.2f worst_xi3=%s c3max=%.2f status=%s\n", Phi[2][i].name, v.obj, v.c2,
                Phi[3][v.jstar].name, maximum(v.c3), v.status)
    end
    println(io, "first-stage plan:"); REVCS33.report_state(I, best.x1; io=io)
end
print(read(joinpath(out, "ccg_summary.txt"), String))
best === nothing && exit()
# Export the evaluated incumbent policy on the same finite tree.
capstr(I, x) = join(["$a:$(x.Cc[a])/$(x.Ce[a])/$(x.Cv[a])" for a in 1:I.A if x.z[a] > 0.5], ";")
open(joinpath(out, "ccg_policy.csv"), "w") do io
    println(io, "stage,path,capacities,inv,man,substation,curtail,imbalance,travel,disc_cost,total_from_here")
    row(st, path, x, p, tot) = println(io, join([st, "\"$path\"", "\"$(capstr(I, x))\"", p.inv, p.man, p.substation,
                                    p.curtail, p.imbalance, p.travel, p.disc_cost, tot], ","))
    row(1, "nominal", best.x1, best.p1, best.c1 + maximum(v.obj for v in best.V))
    for (i, v) in enumerate(best.V)
        row(2, Phi[2][i].name, v.x2, v.parts2, v.obj)
        for (j, sc) in enumerate(Phi[3])
            row(3, Phi[2][i].name * " > " * sc.name, v.x3[j], v.parts3[j], v.c3[j])
        end
    end
end
