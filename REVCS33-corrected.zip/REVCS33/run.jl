# Usage (PowerShell, from the revcs folder):
#   julia --project=. run.jl smoke        # 2 TOIs, 8 scenarios/stage
#   julia --project=. run.jl medium       # 4 TOIs, 8 scenarios/stage  (hours)
#   julia --project=. run.jl full         # 96 TOIs, 36 scenarios/stage
# Optional env: ITERS (default 60), TOL (default 1e-3), LAG (Lagrangian iterations, default 4),
#               SOLVER=highs|scip
include(joinpath(@__DIR__, "REVCS33.jl"))
using .REVCS33, Printf, Dates

preset = isempty(ARGS) ? "smoke" : ARGS[1]
cfg = if preset == "smoke"
    Cfg(days=[1], hours=[9,14], patterns=[:fc,:adv], time_limit=60.0, mip_gap=1e-4)
elseif preset == "medium"
    Cfg(days=[1], hours=[3,9,14,19], patterns=[:fc,:adv], time_limit=300.0, mip_gap=1e-4)
elseif preset == "full"
    Cfg(days=[1,2,3,4], hours=collect(1:24), patterns=[:fc,:lo,:hi,:adv], corner_only=false,
        time_limit=3600.0, mip_gap=1e-4)
else
    error("unknown preset $preset (smoke|medium|full)")
end
cfg.lag_iters = parse(Int, get(ENV, "LAG", "4"))
cfg.solver = Symbol(get(ENV, "SOLVER", "highs"))
if cfg.solver == :scip
    @eval using SCIP
    REVCS33.register_solver!(:scip, SCIP.Optimizer)
end

out = mktempdir(@__DIR__; prefix="out_rddp_" * preset * "_", cleanup=false)
println("Results: ", out)
I = REVCS33.build_inst(cfg)
open(joinpath(out, "settings.txt"), "w") do io
    println(io, "started=", now()); println(io, "preset=", preset)
    for f in fieldnames(Cfg); println(io, f, "=", getfield(cfg, f)); end
    println(io, "TOIs=", I.tois); println(io, "paths=", length(I.paths), " state_bits=", I.nbit)
end
t0 = time()
hist, cuts = REVCS33.rddp(I; max_iter=parse(Int, get(ENV, "ITERS", "60")),
                         tol=parse(Float64, get(ENV, "TOL", "1e-3")), outdir=out)
h = hist[end]
open(joinpath(out, "summary.txt"), "w") do io
    @printf(io, "LB=%.4f\nUB=%.4f\ngap=%.6f%%\niterations=%d\nseconds=%.1f\n", h.LB, h.UB, 100h.gap, h.iter, time()-t0)
    println(io, "certified_feasible_policy=", isfinite(h.UB))
    println(io, "scope=finite uncertainty set (", length(REVCS33.scen_set(I, 2)), " scenarios/stage), TOIs=", length(I.tois))
    isfinite(h.UB) && REVCS33.report_state(I, h.x1; io=io)
end
print(read(joinpath(out, "summary.txt"), String))
